/*
 ThirdScreen.swift
 -EmotionalTesting-
 
 -Created by Juan Harrington on 29/07/22.
 */

/*
 [[BackgroundColors:]]
 -Screen1: 122, 25, 182
 -Screen2: 12, 202, 243
 -Screen3: 23, 193, 30
 */

import SwiftUI
import Foundation


struct ContentViewThree: View {
    
    @State private var stateScreenOne: CGFloat = 1.10
    @State private var stateScreenTwo: CGFloat = 0.70
    
    var body: some View{
        GeometryReader { geometry in
            
            ZStack(alignment: .bottom){
                ZStack{
                    Color(red: 122 / 255, green: 25 / 255, blue: 182 / 255)
                        .ignoresSafeArea()
                    VStack(alignment: .leading){
                        HStack{
                            Image("Vector")
                                .padding(15)
                                .padding(.leading, 25)
                            Text("Titulo")
                                .fontWeight(.heavy)
                                .padding(.top, 10)
                                .padding(.leading, 5)
                                .font(Font.custom("FiraSans-BookItalic.otf", size: 20))
                                .foregroundColor(Color.white)
                            
                        }
                        .padding(.top, 30)
                        
                        
                        Text("Mega ultra texto de la muerte hd increible pitosnt siuuu uuuuuuu uuuuuu uuu")
                            .padding(.leading, 25)
                            .padding(.trailing, 25)
                            .padding(.top, 10)
                            .font(Font.custom("FiraSans-BookItalic.otf", size: 15))
                            .foregroundColor(Color.white)
                        
                        Button("Button title") {
                            print("Button tapped!")
                        }
                        .padding(.top, 20)
                        .padding(.leading, geometry.size.width * 0.35)
                        Spacer()
                    }
                    
                    .padding(.top, 50)
                    
                }
                
                .modifier(EmotionallContentImageStyle())
                .ignoresSafeArea()
                .onTapGesture(count: 1, perform: {
                    stateScreenOne = 0.90
                    stateScreenTwo = 0.50
                    print("a")
                })
                
                
                //Pantallas dos y treh aca abajo
                
                ZStack{
                    Color(red: 12 / 255, green: 202 / 255, blue: 243 / 255)
                        .ignoresSafeArea()
                    
                    VStack(alignment: .leading){
                        HStack{
                            Image("Vector")
                                .padding(15)
                                .padding(.leading, 25)
                            Text("Titulo")
                                .fontWeight(.heavy)
                                .padding(.top, 10)
                                .padding(.leading, 5)
                                .font(Font.custom("FiraSans-BookItalic.otf", size: 20))
                                .foregroundColor(Color.white)
                            
                        }
                        .padding(.top, 50)
                        
                        
                        Text("Mega ultra texto de la muerte hd increible pitosnt siuuu uuuuuuu uuuuuu uuu")
                            .padding(.leading, 25)
                            .padding(.trailing, 25)
                            .padding(.top, 10)
                            .font(Font.custom("FiraSans-BookItalic.otf", size: 15))
                            .foregroundColor(Color.white)
                        
                        Button("Button title") {
                            print("Button tapped!")
                        }
                        .padding(.top, 20)
                        .padding(.leading, geometry.size.width * 0.35)
                        Spacer()
                    }
                }
                
                .frame(height: geometry.size.width * stateScreenOne)
                .modifier(EmotionallContentImageStyle())
                
                .onTapGesture(count: 1, perform: {
                    stateScreenOne = 1.40
                    stateScreenTwo = 0.50
                })
                
                
                ZStack{
                    Color(red: 23 / 255, green: 193 / 193, blue: 30 / 255)
                        .ignoresSafeArea()
                    VStack(alignment: .leading){
                        HStack{
                            Image("Vector")
                                .padding(15)
                                .padding(.leading, 25)
                            Text("Titulo")
                                .fontWeight(.heavy)
                                .padding(.top, 10)
                                .padding(.leading, 5)
                                .font(Font.custom("FiraSans-BookItalic.otf", size: 20))
                                .foregroundColor(Color.white)
                            
                        }
                        .padding(.top, 50)
                        
                        
                        Text("Mega ultra texto de la muerte hd increible pitosnt siuuu uuuuuuu uuuuuu uuu")
                            .padding(.leading, 25)
                            .padding(.trailing, 25)
                            .padding(.top, 10)
                            .font(Font.custom("FiraSans-BookItalic.otf", size: 15))
                            .foregroundColor(Color.white)
                        
                        Button("Button title") {
                            print("Button tapped!")
                        }
                        .padding(.top, 20)
                        .padding(.leading, geometry.size.width * 0.35)
                        Spacer()
                    }
                    
                }
                
                .ignoresSafeArea()
                .frame(height: geometry.size.width * stateScreenTwo)
                .modifier(EmotionallContentImageStyle())
                
                .onTapGesture(count: 1, perform: {
                    stateScreenOne = 1.40
                    stateScreenTwo = 1
                })
            }
        }
    }
}


struct ContentView_PreviewsThree: PreviewProvider {
    static var previews: some View {
        ContentViewThree()
    }
}
